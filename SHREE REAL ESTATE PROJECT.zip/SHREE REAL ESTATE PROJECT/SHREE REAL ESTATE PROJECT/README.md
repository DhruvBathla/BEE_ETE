# ENIGMA-REAL-ESTATES-MERN-STACK-

This website aims to provide a platform for any person interested in searching , posting property or getting in touch with the right brokers. The website also tends to offer exquisite 
features such as latest news , map view and prediction of trends in certain areas.

Contributors:

  https://github.com/jsv1604
  
  https://github.com/KushagraSingh02

